package Controles;

public interface ControlRemoto {
    void encenderApagar();

    void bajarVolumen();

    void subirVolumen();

    void bajarCanal();

    void subirCanal();
}
