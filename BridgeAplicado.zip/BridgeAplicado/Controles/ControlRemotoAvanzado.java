package Controles;

import Dispositivos.Dispositivo;

public class ControlRemotoAvanzado extends ControlRemotoBasico {

    public ControlRemotoAvanzado(Dispositivo dispositivo) {
        super(dispositivo);
    }

    public void silenciar() {
        System.out.println("Control Remoto: silenciar");
        dispositivo.establecerVolumen(0);
    }
}
